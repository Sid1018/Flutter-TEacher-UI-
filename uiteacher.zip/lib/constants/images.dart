const String welcomeImage = 'assets/logo1.png';
const String homeImage = 'assets/logo1.png';
const String searchImage = 'assets/search.svg';
const String playImage = 'assets/play.svg';
const String profileImage = 'assets/logo1.png';
