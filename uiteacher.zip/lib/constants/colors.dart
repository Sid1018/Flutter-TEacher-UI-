import 'package:flutter/material.dart';

const Color primaryColor = Color(0xFF1A237E);
const Color secondaryColor = Color(
  0xFF1A237E,
);
const Color tertiaryColor = Color(0xFFf4f4f4);
const Color textColor = Color(0xFF333333);
const Color labelColor = Color(0xFF8A8989);
const Color notificationColor = Color(0xFFe54140);
const Color blackColor = Color(0xFF3E4249);
