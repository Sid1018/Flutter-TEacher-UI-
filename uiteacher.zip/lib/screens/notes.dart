import 'package:flutter/material.dart';

class NotesSharingPanel extends StatefulWidget {
  @override
  _NotesSharingPanelState createState() => _NotesSharingPanelState();
}

class _NotesSharingPanelState extends State<NotesSharingPanel> {
  final _formKey = GlobalKey<FormState>();
  String _subject, _topic, _noteType, _noteContent;
  List<String> _subjectList = ['Math', 'Science', 'English', 'History'];
  List<String> _noteTypeList = ['Theory', 'Practical', 'Assignment', 'Project'];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Notes Sharing Panel'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              DropdownButtonFormField(
                decoration: InputDecoration(
                  labelText: 'Subject',
                  border: OutlineInputBorder(),
                ),
                value: _subject,
                onChanged: (value) {
                  setState(() {
                    _subject = value;
                  });
                },
                items: _subjectList.map((subjectVal) {
                  return DropdownMenuItem(
                    value: subjectVal,
                    child: Text(subjectVal),
                  );
                }).toList(),
              ),
              SizedBox(height: 20),
              TextFormField(
                decoration: InputDecoration(
                  labelText: 'Topic',
                  border: OutlineInputBorder(),
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter topic';
                  }
                  return null;
                },
                onSaved: (value) => _topic = value,
              ),
              SizedBox(height: 20),
              DropdownButtonFormField(
                decoration: InputDecoration(
                  labelText: 'Note Type',
                  border: OutlineInputBorder(),
                ),
                value: _noteType,
                onChanged: (value) {
                  setState(() {
                    _noteType = value;
                  });
                },
                items: _noteTypeList.map((noteTypeVal) {
                  return DropdownMenuItem(
                    value: noteTypeVal,
                    child: Text(noteTypeVal),
                  );
                }).toList(),
              ),
              SizedBox(height: 20),
              TextFormField(
                decoration: InputDecoration(
                  labelText: 'Note Content',
                  border: OutlineInputBorder(),
                ),
                maxLines: 5,
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter note content';
                  }
                  return null;
                },
                onSaved: (value) => _noteContent = value,
              ),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: () {
                  if (_formKey.currentState.validate()) {
                    _formKey.currentState.save();
                    // Add logic to share notes here
                    print('Notes shared successfully!');
                  }
                },
                child: Text('Share Notes'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
