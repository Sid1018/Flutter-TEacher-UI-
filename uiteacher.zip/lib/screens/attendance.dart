import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Attendance Marking Panel',
      theme: ThemeData(
        primarySwatch: Color(0xff012441),
      ),
      home: AttendanceMarkingPanel(),
    );
  }
}

class AttendanceMarkingPanel extends StatefulWidget {
  @override
  _AttendanceMarkingPanelState createState() => _AttendanceMarkingPanelState();
}

class _AttendanceMarkingPanelState extends State<AttendanceMarkingPanel> {
  List<String> students = ['Sid', 'Ashwin', 'Harsidh'];
  List<bool> attendance = List.filled(3, false);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Attendance Marking Panel'),
      ),
      body: ListView.builder(
        itemCount: students.length,
        itemBuilder: (context, index) {
          return ListTile(
            leading: CircleAvatar(child: Text('${index + 1}')),
            title: Text(students[index]),
            trailing: Checkbox(
              value: attendance[index],
              onChanged: (value) {
                setState(() {
                  attendance[index] = value;
                });
              },
            ),
          );
        },
      ),
    );
  }
}
