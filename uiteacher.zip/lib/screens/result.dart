import 'package:flutter/material.dart';

class ResultDeclarationPanel extends StatefulWidget {
  @override
  _ResultDeclarationPanelState createState() => _ResultDeclarationPanelState();
}

class _ResultDeclarationPanelState extends State<ResultDeclarationPanel> {
  final _formKey = GlobalKey<FormState>();
  String _className, _section, _examType, _resultStatus;
  List<String> _classList = [
    'Class 1',
    'Class 2',
    'Class 3',
    'Class 4',
    'Class 5'
  ];
  List<String> _sectionList = ['A', 'B', 'C', 'D'];
  List<String> _examTypeList = ['Mid Term', 'Final Term', 'Quarterly'];
  List<String> _resultStatusList = ['Declared', 'Not Declared'];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Result Declaration Panel'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              DropdownButtonFormField(
                decoration: InputDecoration(
                  labelText: 'Class',
                  border: OutlineInputBorder(),
                ),
                value: _className,
                onChanged: (value) {
                  setState(() {
                    _className = value;
                  });
                },
                items: _classList.map((classVal) {
                  return DropdownMenuItem(
                    value: classVal,
                    child: Text(classVal),
                  );
                }).toList(),
              ),
              SizedBox(height: 20),
              DropdownButtonFormField(
                decoration: InputDecoration(
                  labelText: 'Section',
                  border: OutlineInputBorder(),
                ),
                value: _section,
                onChanged: (value) {
                  setState(() {
                    _section = value;
                  });
                },
                items: _sectionList.map((sectionVal) {
                  return DropdownMenuItem(
                    value: sectionVal,
                    child: Text(sectionVal),
                  );
                }).toList(),
              ),
              SizedBox(height: 20),
              DropdownButtonFormField(
                decoration: InputDecoration(
                  labelText: 'Exam Type',
                  border: OutlineInputBorder(),
                ),
                value: _examType,
                onChanged: (value) {
                  setState(() {
                    _examType = value;
                  });
                },
                items: _examTypeList.map((examTypeVal) {
                  return DropdownMenuItem(
                    value: examTypeVal,
                    child: Text(examTypeVal),
                  );
                }).toList(),
              ),
              SizedBox(height: 20),
              DropdownButtonFormField(
                decoration: InputDecoration(
                  labelText: 'Result Status',
                  border: OutlineInputBorder(),
                ),
                value: _resultStatus,
                onChanged: (value) {
                  setState(() {
                    _resultStatus = value;
                  });
                },
                items: _resultStatusList.map((resultStatusVal) {
                  return DropdownMenuItem(
                    value: resultStatusVal,
                    child: Text(resultStatusVal),
                  );
                }).toList(),
              ),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: () {
                  // Add logic to declare result here
                  print('Result declared successfully!');
                },
                child: Text('Declare Result'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
