List courses = [
  {
    "id": 1,
    "name": "Intro to UI/UX Design",
    "image":
        "https://images.unsplash.com/photo-1596638787647-904d822d751e?ixid=MXwxMjA3fDB8MHxzZWFyY2h8MTF8fGZhc2hpb258ZW58MHx8MHw%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=60",
    "duration": "4 hours",
    "session": "6 lessons",
    "review": "4.2",
    "description": "",
  },
  {
    "id": 2,
    "name": "Intro to Programming using C",
    "image":
        "https://images.unsplash.com/photo-1517694712202-14dd9538aa97?ixid=MXwxMjA3fDB8MHxzZWFyY2h8MTF8fGZhc2hpb258ZW58MHx8MHw%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=60",
    "duration": "3 hours",
    "session": "12 lessons",
    "review": "3",
    "description": "",
  },
  {
    "id": 3,
    "name": "Academic Writing",
    "image":
        "https://images.unsplash.com/photo-1522881451255-f59ad836fdfb?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1944&q=80",
    "duration": "7 hours",
    "session": "4 lessons",
    "review": "4.1",
    "description": "",
  },
  {
    "id": 4,
    "name": "Financial Literacy",
    "image":
        "https://images.unsplash.com/photo-1460925895917-afdab827c52f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2015&q=80",
    "duration": "4 hours",
    "session": "3 lessons",
    "review": "4.2",
    "description": "",
  },
  {
    "id": 5,
    "name": "Basic Accounting",
    "image":
        "https://images.unsplash.com/photo-1554224155-3a58922a22c3?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2041&q=80",
    "duration": "9 hours",
    "session": "5 lessons",
    "review": "4.5",
    "description": "",
  }
];
