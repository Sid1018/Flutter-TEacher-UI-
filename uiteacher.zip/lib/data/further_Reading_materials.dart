List furtherReadings = [
  {
    "id": 1,
    "course": "Engineering",
    "image":
        "https://images.unsplash.com/photo-1490775949603-0e355e8e01ba?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2066&q=80",
    "location": "Balme Library",
    "duration": "6 hours",
    "review": "4.2",
    "description": ".",
  },
  {
    "id": 2,
    "course": "Mathematics",
    "image":
        "https://images.unsplash.com/photo-1509228468518-180dd4864904?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80",
    "location": "Balme Library",
    "duration": "6 hours",
    "review": "4.5",
    "description": ".",
  },
  {
    "id": 3,
    "course": "Aquaculture",
    "image":
        "https://images.unsplash.com/photo-1649347173558-a305d7b8ff98?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1974&q=80",
    "location": "Balme Library",
    "duration": "6 hours",
    "review": "4.3",
    "description": ".",
  },
  {
    "id": 4,
    "course": "Agriculture",
    "image":
        "https://images.unsplash.com/photo-1627920769842-6887c6df05ca?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1933&q=80",
    "location": "Balme Library",
    "duration": "6 hours",
    "review": "4.1",
    "description": ".",
  }
];
