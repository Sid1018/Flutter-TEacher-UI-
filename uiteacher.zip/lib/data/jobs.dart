List jobs = [
  {"id": 1, "name": "XYZ", 'company': 'XYZ', "location": "XYZ", "logo": ""},
  {"id": 2, "name": "XYZ", "company": "XYZ", "location": "XYZ", "logo": ""},
  {"id": 3, "name": "XYZ", "company": "XYZ", "location": "XYZ", "logo": ""},
  {"id": 4, "name": "XYZ", "company": "XYZ", "location": "XYZ", "logo": ""},
  {"id": 5, "name": "XYZ", "company": "XYZ", "location": "XYZ", "logo": ""},
];

List popularJobs = [
  {
    "id": 1,
    "name": "TXYZ",
    "department": "XYZ",
  },
  {
    "id": 2,
    "name": "XYZ",
    "department": "XYZ",
  },
  {
    "id": 3,
    "name": "XYZ",
    "department": "XYZ",
  },
  {
    "id": 4,
    "name": "XYZ",
    "department": "XYZ",
  },
];
