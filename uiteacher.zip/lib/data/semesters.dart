List semesters = [
  {"name": "Class 1", "text": "1"},
  {"name": "Class 2", "text": "2"},
  {"name": "Class 3", "text": "3"},
  {"name": "Class 4", "text": "4"},
  {"name": "Class 5", "text": "5"},
  {"name": "Class 6", "text": "6"},
  {"name": "Class 7", "text": "7"},
  {"name": "Class 8", "text": "8"},
];
