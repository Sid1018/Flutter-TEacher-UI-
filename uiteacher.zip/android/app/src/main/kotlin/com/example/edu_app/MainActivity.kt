package com.example.edu_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
